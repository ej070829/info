const auth = firebase.auth();

// 로그인 상태 체크 - 비로그인이면 login.html로 강제 이동
auth.onAuthStateChanged(user => {
  if (user) {
    document.getElementById('welcome-msg').textContent =
      user.email + ' 님, 환영합니다!';
  } else {
    alert('로그인이 필요합니다.');
    location.href = 'login.html';
  }
});

// 로그아웃
function logout() {
  auth.signOut().then(() => {
    alert('로그아웃 되었습니다.');
    location.href = 'index.html';
  });
}
